# Visual Gallery (practice exercises)

One page per visual type. Screenshots are in `screenshots/`. Datasets come from my course and from sample files; I have not included the data files.

| # | Page | Visual | Fields used | What I learned |
|---|---|---|---|---|
| 1 | DashBoard (restaurant orders) | Clustered bar chart | Restaurant type by count of quantity and order ID | [fill in] |
| 2 | Line | Line chart | Month by sum of quantity ordered and order line number | [fill in] |
| 3 | Waterfall | Waterfall chart | Member states by population (thousands) | [fill in] |
| 4 | Funnel | Funnel chart | Step by quantity (million tons) | [fill in] |
| 5 | Scatter | Scatter chart | Advertising costs vs sales figures, by days | [fill in] |
| 6 | Pie/Donut | Donut chart | Territory by count of quantity ordered | [fill in] |
| 7 | Tree | Treemap | Region by CO2 in tonnes | [fill in] |
| 8 | MAP/Fill_map | Map | Country and region by average biocapacity | [fill in] |
| 9 | Gauge | Gauge with slicer | Target value, target achieved, maximum value; salesman slicer | [fill in] |
| 10 | KPI | KPI visual with date slicer | Target sales vs actual sales, status | [fill in] |
| 11 | Page 1 | Cards, column chart, slicer | Quantity statistics; count of state by order status | [fill in] |
| 12 | Image slicer | Pie chart with image slicer | Sales by employee | [fill in] |
| 13 | table | Table | State by sum and max quantity | [fill in] |
| 14 | Date DAX | (planned) | Date table and time intelligence measures | see `dax-notes/` |

Replace each `[fill in]` with one real sentence before you publish.
