# Dashboard 1: Customer Churn

Full project (SQL pipeline, model and dashboard): https://github.com/Pratham8765/Customer-Churn-Prediction

Add `overview.png` here and write 3 findings in your own words.
