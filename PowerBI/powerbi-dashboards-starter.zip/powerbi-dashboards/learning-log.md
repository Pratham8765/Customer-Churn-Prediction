# Learning Log

| Date | What I learned | What I built or committed |
|---|---|---|
| YYYY-MM-DD | [one sentence] | [file or screenshot] |
