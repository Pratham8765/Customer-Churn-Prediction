# Power BI Learning and Dashboards

My Power BI practice and portfolio: visual exercises, DAX notes and dashboards.

> **Honest note:** the visual gallery contains learning exercises built on course and sample datasets. My full analysis project is the customer churn dashboard (linked below).

## Dashboards
| # | Dashboard | Data | Main finding |
|---|---|---|---|
| 1 | [Customer Churn](https://github.com/Pratham8765/Customer-Churn-Prediction) | Telco churn data (course dataset, not included) | Month-to-month contracts churn at 43% vs 3% on two-year contracts |

## What is in this repo
- `visual-gallery/`: one screenshot per visual type I practiced, with a short note on what I learned
- `dax-notes/`: DAX measures and notes (date table, time intelligence)
- `dashboards/`: write-ups and screenshots of larger dashboards
- `learning-log.md`: short dated notes on what I learned

## Tools
Power BI Desktop, DAX, Power Query, SQL (SQLite)
